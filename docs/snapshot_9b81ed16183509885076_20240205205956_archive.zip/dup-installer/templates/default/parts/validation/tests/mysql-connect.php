<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?><p>
    Support for the PHP <a href='http://us2.php.net/manual/en/mysqli.installation.php' target='_blank'>mysqli extension</a> is required.
    Please contact your hosting provider or server administrator to enable the mysqli extension.  <i>The detection for this call uses
        the function_exists('mysqli_connect') call.</i>
</p>